import { useState, useEffect, useCallback, useRef, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  BookOpen,
  PenTool,
  Brain,
  Trophy,
  Search,
  X,
  ChevronLeft,
  Star,
  Volume2,
  RotateCcw,
  Check,
  Sparkles,
  TrendingUp,
  Award,
  Target,
  ArrowRight,
  Lightbulb,
  Eraser,
  Minus,
  Plus,
} from "lucide-react";
import { kanjiData, categories } from "./data/kanjiData";
import type { KanjiItem } from "./data/kanjiData";

// ─── Starfield Background ─────────────────────────────────────────
function Starfield() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId: number;
    const stars: { x: number; y: number; r: number; speed: number; opacity: number }[] = [];

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener("resize", resize);

    for (let i = 0; i < 200; i++) {
      stars.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        r: Math.random() * 1.5 + 0.3,
        speed: Math.random() * 0.3 + 0.05,
        opacity: Math.random() * 0.8 + 0.2,
      });
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      stars.forEach((star) => {
        star.y += star.speed;
        if (star.y > canvas.height) {
          star.y = 0;
          star.x = Math.random() * canvas.width;
        }
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(230, 241, 255, ${star.opacity})`;
        ctx.fill();
      });
      animId = requestAnimationFrame(animate);
    };
    animate();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none"
      style={{ zIndex: 0 }}
    />
  );
}

// ─── Writing Canvas ───────────────────────────────────────────────
function WritingCanvas({
  kanji,
  onClose,
  onComplete,
}: {
  kanji: string;
  onClose: () => void;
  onComplete: () => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [brushSize, setBrushSize] = useState(8);
  const [brushColor, setBrushColor] = useState("#00F0FF");
  const [completed, setCompleted] = useState(false);
  const [strokes, setStrokes] = useState(0);

  const getPos = useCallback(
    (e: React.MouseEvent | React.TouchEvent) => {
      const canvas = canvasRef.current;
      if (!canvas) return { x: 0, y: 0 };
      const rect = canvas.getBoundingClientRect();
      const clientX = "touches" in e ? e.touches[0].clientX : e.clientX;
      const clientY = "touches" in e ? e.touches[0].clientY : e.clientY;
      return {
        x: clientX - rect.left,
        y: clientY - rect.top,
      };
    },
    []
  );

  const startDrawing = useCallback(
    (e: React.MouseEvent | React.TouchEvent) => {
      setIsDrawing(true);
      const { x, y } = getPos(e);
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext("2d");
      if (ctx) {
        ctx.beginPath();
        ctx.moveTo(x, y);
      }
    },
    [getPos]
  );

  const draw = useCallback(
    (e: React.MouseEvent | React.TouchEvent) => {
      if (!isDrawing) return;
      const { x, y } = getPos(e);
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext("2d");
      if (ctx) {
        ctx.lineTo(x, y);
        ctx.strokeStyle = brushColor;
        ctx.lineWidth = brushSize;
        ctx.lineCap = "round";
        ctx.lineJoin = "round";
        ctx.shadowBlur = 10;
        ctx.shadowColor = brushColor;
        ctx.stroke();
      }
    },
    [isDrawing, getPos, brushColor, brushSize]
  );

  const stopDrawing = useCallback(() => {
    if (isDrawing) {
      setIsDrawing(false);
      setStrokes((p) => p + 1);
    }
  }, [isDrawing]);

  const clearCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (ctx && canvas) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      setStrokes(0);
      setCompleted(false);
    }
  }, []);

  const handleComplete = useCallback(() => {
    setCompleted(true);
    onComplete();
  }, [onComplete]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const resize = () => {
      const parent = canvas.parentElement;
      if (parent) {
        canvas.width = parent.clientWidth;
        canvas.height = parent.clientHeight;
      }
    };
    resize();
    window.addEventListener("resize", resize);
    return () => window.removeEventListener("resize", resize);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex flex-col"
      style={{ background: "rgba(5, 5, 8, 0.95)" }}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4">
        <button
          onClick={onClose}
          className="flex items-center gap-2 text-sm text-[#E6F1FF]/60 hover:text-[#00F0FF] transition-colors"
        >
          <ChevronLeft size={18} />
          ফিরে যান
        </button>
        <h2 className="text-lg font-semibold text-[#E6F1FF]">
          <span className="font-jp-serif text-3xl text-[#00F0FF] mr-3">{kanji}</span>
          লেখার অনুশীলন
        </h2>
        <div className="flex items-center gap-2">
          <span className="text-xs text-[#E6F1FF]/40">স্ট্রোক: {strokes}</span>
        </div>
      </div>

      {/* Canvas Area */}
      <div className="flex-1 relative mx-6 mb-4 rounded-2xl overflow-hidden border border-[#00F0FF]/10">
        {/* Ghost Kanji */}
        <div
          className="absolute inset-0 flex items-center justify-center pointer-events-none select-none font-jp-serif"
          style={{
            fontSize: "clamp(200px, 40vw, 400px)",
            color: "rgba(0, 240, 255, 0.06)",
            zIndex: 1,
          }}
        >
          {kanji}
        </div>

        {/* Grid Lines */}
        <svg
          className="absolute inset-0 pointer-events-none"
          style={{ zIndex: 2 }}
          width="100%"
          height="100%"
        >
          <line x1="50%" y1="0" x2="50%" y2="100%" stroke="rgba(0,240,255,0.08)" strokeWidth="1" strokeDasharray="4 4" />
          <line x1="0" y1="50%" x2="100%" y2="50%" stroke="rgba(0,240,255,0.08)" strokeWidth="1" strokeDasharray="4 4" />
          <line x1="0" y1="0" x2="100%" y2="100%" stroke="rgba(0,240,255,0.05)" strokeWidth="1" strokeDasharray="4 4" />
          <line x1="100%" y1="0" x2="0" y2="100%" stroke="rgba(0,240,255,0.05)" strokeWidth="1" strokeDasharray="4 4" />
        </svg>

        {/* Drawing Canvas */}
        <canvas
          ref={canvasRef}
          className="absolute inset-0 cursor-crosshair"
          style={{ zIndex: 3 }}
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
          onTouchStart={startDrawing}
          onTouchMove={draw}
          onTouchEnd={stopDrawing}
        />

        {/* Completion Overlay */}
        <AnimatePresence>
          {completed && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 flex items-center justify-center"
              style={{ zIndex: 4, background: "rgba(5,5,8,0.7)" }}
            >
              <div className="text-center">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", damping: 10 }}
                  className="font-jp-serif text-[120px] text-[#FF006E] glow-magenta mb-4"
                >
                  {kanji}
                </motion.div>
                <p className="text-xl text-[#00F0FF] font-semibold mb-2">দারুণ!</p>
                <p className="text-sm text-[#E6F1FF]/60 mb-6">এই কানজিটি শেখা সম্পূর্ণ হয়েছে</p>
                <button onClick={onClose} className="btn-primary">
                  পরবর্তী কানজি
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Toolbar */}
      <div className="px-6 pb-6 flex items-center justify-center gap-4 flex-wrap">
        {/* Brush Size */}
        <div className="flex items-center gap-2 glass-card rounded-xl px-4 py-2">
          <Minus size={14} className="text-[#E6F1FF]/40" />
          <input
            type="range"
            min={2}
            max={30}
            value={brushSize}
            onChange={(e) => setBrushSize(Number(e.target.value))}
            className="w-24 accent-[#00F0FF]"
          />
          <Plus size={14} className="text-[#E6F1FF]/40" />
          <span className="text-xs text-[#E6F1FF]/60 ml-1 w-6">{brushSize}</span>
        </div>

        {/* Colors */}
        <div className="flex items-center gap-2 glass-card rounded-xl px-4 py-2">
          {["#00F0FF", "#FF006E", "#FFD700", "#ffffff", "#E6F1FF"].map((c) => (
            <button
              key={c}
              onClick={() => setBrushColor(c)}
              className="w-6 h-6 rounded-full border-2 transition-all duration-200"
              style={{
                backgroundColor: c,
                borderColor: brushColor === c ? "#E6F1FF" : "transparent",
                transform: brushColor === c ? "scale(1.2)" : "scale(1)",
              }}
            />
          ))}
        </div>

        {/* Actions */}
        <button onClick={clearCanvas} className="btn-secondary flex items-center gap-2">
          <Eraser size={16} />
          মুছুন
        </button>

        {!completed && (
          <button onClick={handleComplete} className="btn-primary flex items-center gap-2">
            <Check size={16} />
            সম্পূর্ণ
          </button>
        )}
      </div>
    </motion.div>
  );
}

// ─── Study Card Modal ─────────────────────────────────────────────
function StudyCard({
  kanji,
  onClose,
  onWrite,
  isLearned,
  onToggleLearned,
}: {
  kanji: KanjiItem;
  onClose: () => void;
  onWrite: () => void;
  isLearned: boolean;
  onToggleLearned: () => void;
}) {
  const [flipped, setFlipped] = useState(false);

  const speak = (text: string) => {
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = "ja-JP";
    utter.rate = 0.75;
    speechSynthesis.cancel();
    speechSynthesis.speak(utter);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "rgba(5, 5, 8, 0.85)", backdropFilter: "blur(12px)" }}
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.8, y: 50 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.8, y: 50 }}
        transition={{ type: "spring", damping: 25 }}
        className="w-full max-w-lg glass-panel rounded-3xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Card Header */}
        <div className="relative p-6 pb-4">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full hover:bg-[#00F0FF]/10 transition-colors"
          >
            <X size={20} className="text-[#E6F1FF]/60" />
          </button>

          <div className="flex items-center gap-3 mb-4">
            <span className="text-xs font-mono text-[#00F0FF]/60">#{kanji.id}</span>
            <span className="category-chip text-[10px] px-2 py-0.5">{kanji.category}</span>
            <button
              onClick={() => onToggleLearned()}
              className="ml-auto p-2 rounded-full transition-all duration-300"
              style={{
                background: isLearned ? "rgba(255, 0, 110, 0.2)" : "rgba(0, 240, 255, 0.05)",
              }}
            >
              <Star
                size={18}
                className={isLearned ? "text-[#FF006E] fill-[#FF006E]" : "text-[#E6F1FF]/30"}
              />
            </button>
          </div>

          {/* Main Kanji */}
          <div className="flex items-start gap-6">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => speak(kanji.kanji)}
              className="relative flex-shrink-0 w-28 h-28 rounded-2xl flex items-center justify-center"
              style={{
                background: "linear-gradient(135deg, rgba(0,240,255,0.1), rgba(255,0,110,0.1))",
                border: "1px solid rgba(0,240,255,0.2)",
              }}
            >
              <span className="font-jp-serif text-7xl text-[#E6F1FF]">{kanji.kanji}</span>
              <Volume2
                size={16}
                className="absolute bottom-2 right-2 text-[#00F0FF]/60"
              />
            </motion.button>

            <div className="flex-1 min-w-0">
              <h3 className="text-xl font-bold text-[#E6F1FF] mb-1">{kanji.bn}</h3>
              <div className="space-y-1.5 text-sm">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase tracking-wider text-[#00F0FF]/60 w-16">On'yomi</span>
                  <button onClick={() => speak(kanji.on)} className="font-jp text-[#E6F1FF]/80 hover:text-[#00F0FF] transition-colors flex items-center gap-1">
                    {kanji.on}
                    <Volume2 size={12} />
                  </button>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase tracking-wider text-[#FF006E]/60 w-16">Kun'yomi</span>
                  <button onClick={() => speak(kanji.kun)} className="font-jp text-[#E6F1FF]/80 hover:text-[#FF006E] transition-colors flex items-center gap-1">
                    {kanji.kun}
                    <Volume2 size={12} />
                  </button>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase tracking-wider text-[#FFD700]/60 w-16">Strokes</span>
                  <span className="text-[#E6F1FF]/60">{kanji.strokes}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Mnemonic */}
        {kanji.mnemonic && (
          <div className="px-6 py-3 mx-6 rounded-xl" style={{ background: "rgba(255, 215, 0, 0.05)", border: "1px solid rgba(255,215,0,0.1)" }}>
            <div className="flex items-start gap-2">
              <Lightbulb size={14} className="text-[#FFD700] mt-0.5 flex-shrink-0" />
              <p className="text-xs text-[#E6F1FF]/70 leading-relaxed">{kanji.mnemonic}</p>
            </div>
          </div>
        )}

        {/* Examples */}
        <div className="px-6 py-4">
          <h4 className="text-xs uppercase tracking-wider text-[#E6F1FF]/40 mb-3">উদাহরণ</h4>
          <div className="space-y-2">
            {kanji.examples.map((ex, i) => (
              <motion.button
                key={i}
                whileHover={{ x: 4 }}
                onClick={() => speak(ex.word)}
                className="w-full text-left p-3 rounded-xl transition-all duration-200 hover:bg-[#00F0FF]/5"
                style={{ border: "1px solid rgba(0,240,255,0.06)" }}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-jp text-[#E6F1FF] font-medium">{ex.word}</span>
                    <span className="font-jp text-xs text-[#E6F1FF]/40 ml-2">{ex.reading}</span>
                  </div>
                  <span className="text-xs text-[#E6F1FF]/50">{ex.meaning}</span>
                </div>
              </motion.button>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className="px-6 pb-6 pt-2 flex gap-3">
          <button onClick={onWrite} className="btn-primary flex-1 flex items-center justify-center gap-2">
            <PenTool size={16} />
            লেখার অনুশীলন
          </button>
          <button onClick={() => setFlipped(!flipped)} className="btn-secondary flex items-center justify-center gap-2">
            <RotateCcw size={16} />
            কুইজ
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

// ─── Quiz Mode ────────────────────────────────────────────────────
function QuizMode({
  onClose,
}: {
  onClose: () => void;
}) {
  const [currentQ, setCurrentQ] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [questions, setQuestions] = useState<
    { kanji: KanjiItem; options: KanjiItem[]; type: "meaning" | "reading" }[]
  >([]);

  useEffect(() => {
    const pool = kanjiData.sort(() => Math.random() - 0.5).slice(0, 10);
    const qs = pool.map((k) => {
      const type = Math.random() > 0.5 ? ("meaning" as const) : ("reading" as const);
      const wrong = kanjiData
        .filter((x) => x.id !== k.id)
        .sort(() => Math.random() - 0.5)
        .slice(0, 3);
      return {
        kanji: k,
        options: [k, ...wrong].sort(() => Math.random() - 0.5),
        type,
      };
    });
    setQuestions(qs);
  }, []);

  const handleAnswer = (opt: KanjiItem) => {
    if (selected !== null) return;
    setSelected(opt.id);
    if (opt.id === questions[currentQ].kanji.id) {
      setScore((s) => s + 1);
    }
    setTimeout(() => {
      if (currentQ < questions.length - 1) {
        setCurrentQ((c) => c + 1);
        setSelected(null);
      } else {
        setShowResult(true);
      }
    }, 1200);
  };

  const restart = () => {
    const pool = kanjiData.sort(() => Math.random() - 0.5).slice(0, 10);
    const qs = pool.map((k) => {
      const type = Math.random() > 0.5 ? ("meaning" as const) : ("reading" as const);
      const wrong = kanjiData
        .filter((x) => x.id !== k.id)
        .sort(() => Math.random() - 0.5)
        .slice(0, 3);
      return {
        kanji: k,
        options: [k, ...wrong].sort(() => Math.random() - 0.5),
        type,
      };
    });
    setQuestions(qs);
    setCurrentQ(0);
    setScore(0);
    setSelected(null);
    setShowResult(false);
  };

  if (questions.length === 0) return null;

  const q = questions[currentQ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex flex-col"
      style={{ background: "rgba(5, 5, 8, 0.95)" }}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4">
        <button
          onClick={onClose}
          className="flex items-center gap-2 text-sm text-[#E6F1FF]/60 hover:text-[#00F0FF] transition-colors"
        >
          <ChevronLeft size={18} />
          ফিরে যান
        </button>
        <div className="flex items-center gap-3">
          <span className="text-xs text-[#E6F1FF]/40">
            প্রশ্ন {currentQ + 1} / {questions.length}
          </span>
          <div className="w-32 h-2 rounded-full bg-[#E6F1FF]/10 overflow-hidden">
            <motion.div
              className="h-full rounded-full"
              style={{ background: "linear-gradient(90deg, #00F0FF, #FF006E)" }}
              initial={{ width: 0 }}
              animate={{ width: `${((currentQ + 1) / questions.length) * 100}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>
        </div>
        <span className="text-sm font-semibold text-[#FFD700]">স্কোর: {score}</span>
      </div>

      {/* Quiz Content */}
      <div className="flex-1 flex items-center justify-center p-6">
        <AnimatePresence mode="wait">
          {!showResult ? (
            <motion.div
              key={currentQ}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="w-full max-w-md"
            >
              {/* Question */}
              <div className="text-center mb-8">
                <p className="text-sm text-[#E6F1FF]/50 mb-4">
                  {q.type === "meaning"
                    ? "এই কানজির বাংলা অর্থ কী?"
                    : "এই কানজির পড়া ( reading ) কী?"}
                </p>
                <motion.div
                  initial={{ scale: 0.5 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", damping: 15 }}
                  className="font-jp-serif text-[100px] text-[#00F0FF] text-glow-cyan"
                >
                  {q.kanji.kanji}
                </motion.div>
              </div>

              {/* Options */}
              <div className="space-y-3">
                {q.options.map((opt) => {
                  const isSelected = selected === opt.id;
                  const isCorrect = opt.id === q.kanji.id;
                  let btnStyle = "glass-card";
                  if (selected !== null) {
                    if (isCorrect) btnStyle = "bg-[#00F0FF]/20 border-[#00F0FF]";
                    else if (isSelected && !isCorrect) btnStyle = "bg-red-500/20 border-red-500";
                  }

                  return (
                    <motion.button
                      key={opt.id}
                      whileHover={selected === null ? { scale: 1.02 } : {}}
                      whileTap={selected === null ? { scale: 0.98 } : {}}
                      onClick={() => handleAnswer(opt)}
                      className={`w-full p-4 rounded-xl text-left transition-all duration-300 border ${btnStyle}`}
                      disabled={selected !== null}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[#E6F1FF] font-medium">
                          {q.type === "meaning" ? opt.bn : `${opt.on} / ${opt.kun}`}
                        </span>
                        {selected !== null && isCorrect && (
                          <Check size={18} className="text-[#00F0FF]" />
                        )}
                        {selected !== null && isSelected && !isCorrect && (
                          <X size={18} className="text-red-400" />
                        )}
                      </div>
                    </motion.button>
                  );
                })}
              </div>
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", damping: 10, delay: 0.2 }}
              >
                <Trophy size={64} className="text-[#FFD700] mx-auto mb-4" />
              </motion.div>
              <h2 className="text-3xl font-bold text-[#E6F1FF] mb-2">কুইজ শেষ!</h2>
              <p className="text-lg text-[#E6F1FF]/60 mb-2">
                তোমার স্কোর: <span className="text-[#FFD700] font-bold">{score}</span> / {questions.length}
              </p>
              <p className="text-sm text-[#E6F1FF]/40 mb-8">
                {score === 10
                  ? "পারফেক্ট! অসাধারণ!"
                  : score >= 7
                  ? "দারুণ পারফরম্যান্স!"
                  : score >= 5
                  ? "ভালো, আরও অনুশীলন করো!"
                  : "আরও অনুশীলন করতে হবে!"}
              </p>
              <div className="flex gap-4 justify-center">
                <button onClick={restart} className="btn-primary flex items-center gap-2">
                  <RotateCcw size={16} />
                  আবার চেষ্টা
                </button>
                <button onClick={onClose} className="btn-secondary">
                  বন্ধ করুন
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────
type View = "dashboard" | "deck" | "quiz" | "progress" | "write";

export default function App() {
  const [view, setView] = useState<View>("dashboard");
  const [selectedKanji, setSelectedKanji] = useState<KanjiItem | null>(null);
  const [writingKanji, setWritingKanji] = useState<KanjiItem | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("সব");
  const [learnedKanji, setLearnedKanji] = useState<Set<number>>(() => {
    const saved = localStorage.getItem("kanjicosmos-learned");
    return saved ? new Set(JSON.parse(saved)) : new Set<number>();
  });

  // Save learned kanji
  useEffect(() => {
    localStorage.setItem("kanjicosmos-learned", JSON.stringify([...learnedKanji]));
  }, [learnedKanji]);

  const toggleLearned = useCallback((id: number) => {
    setLearnedKanji((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const filteredKanji = useMemo(() => {
    return kanjiData.filter((k) => {
      const matchesCategory = activeCategory === "সব" || k.category === activeCategory;
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        k.kanji.includes(q) ||
        k.bn.includes(q) ||
        k.on.toLowerCase().includes(q) ||
        k.kun.toLowerCase().includes(q) ||
        k.examples.some((e) => e.word.includes(q) || e.meaning.includes(q));
      return matchesCategory && matchesSearch;
    });
  }, [activeCategory, searchQuery]);

  const masteredCount = learnedKanji.size;
  const totalCount = kanjiData.length;
  const progressPercent = Math.round((masteredCount / totalCount) * 100);

  // Find next unlearned kanji for dashboard
  const nextKanji = useMemo(() => {
    return kanjiData.find((k) => !learnedKanji.has(k.id)) || kanjiData[0];
  }, [learnedKanji]);

  // ─── Dashboard View ─────────────────────────────────────────────
  const DashboardView = () => (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="relative z-10 px-4 pt-6 pb-32 max-w-lg mx-auto"
    >
      {/* Greeting */}
      <div className="mb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <h1 className="text-3xl font-bold text-[#E6F1FF] mb-1">
            <span className="gradient-text">KanjiCosmos</span>
          </h1>
          <p className="text-sm text-[#E6F1FF]/50">N5 কানজি মাস্টার করো — একটির পর একটি</p>
        </motion.div>
      </div>

      {/* Progress Summary */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="glass-card rounded-2xl p-5 mb-6"
      >
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Target size={16} className="text-[#00F0FF]" />
            <span className="text-sm text-[#E6F1FF]/70">অগ্রগতি</span>
          </div>
          <span className="text-sm font-bold text-[#00F0FF]">{progressPercent}%</span>
        </div>
        <div className="w-full h-3 rounded-full bg-[#E6F1FF]/10 overflow-hidden">
          <motion.div
            className="h-full rounded-full"
            style={{ background: "linear-gradient(90deg, #00F0FF, #FF006E)" }}
            initial={{ width: 0 }}
            animate={{ width: `${progressPercent}%` }}
            transition={{ duration: 1, ease: "easeOut" }}
          />
        </div>
        <p className="text-xs text-[#E6F1FF]/40 mt-2">
          {masteredCount} / {totalCount} কানজি শেখা হয়েছে
        </p>
      </motion.div>

      {/* Today's Kanji */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="mb-6"
      >
        <h2 className="text-sm font-semibold text-[#E6F1FF]/60 mb-3 flex items-center gap-2">
          <Sparkles size={14} className="text-[#FFD700]" />
          পরবর্তী কানজি
        </h2>
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setSelectedKanji(nextKanji)}
          className="w-full glass-panel rounded-2xl p-5 text-left transition-all duration-300 hover:border-[#00F0FF]/30"
        >
          <div className="flex items-center gap-5">
            <div
              className="w-20 h-20 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{
                background: "linear-gradient(135deg, rgba(0,240,255,0.15), rgba(255,0,110,0.15))",
                border: "1px solid rgba(0,240,255,0.2)",
              }}
            >
              <span className="font-jp-serif text-5xl text-[#E6F1FF]">{nextKanji.kanji}</span>
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-lg font-bold text-[#E6F1FF] mb-0.5">{nextKanji.bn}</h3>
              <p className="font-jp text-sm text-[#E6F1FF]/50 mb-1">
                {nextKanji.on} / {nextKanji.kun}
              </p>
              <p className="text-xs text-[#00F0FF]/60">{nextKanji.category} • {nextKanji.strokes} স্ট্রোক</p>
            </div>
            <ArrowRight size={18} className="text-[#00F0FF]/40 flex-shrink-0" />
          </div>
        </motion.button>
      </motion.div>

      {/* Quick Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="grid grid-cols-2 gap-3"
      >
        <button
          onClick={() => setView("deck")}
          className="glass-card rounded-2xl p-4 text-left hover:border-[#00F0FF]/30 transition-all duration-300 group"
        >
          <BookOpen size={20} className="text-[#00F0FF] mb-2 group-hover:scale-110 transition-transform" />
          <p className="text-sm font-semibold text-[#E6F1FF]">সব কানজি</p>
          <p className="text-xs text-[#E6F1FF]/40">{totalCount}টি কানজি</p>
        </button>
        <button
          onClick={() => setView("quiz")}
          className="glass-card rounded-2xl p-4 text-left hover:border-[#FF006E]/30 transition-all duration-300 group"
        >
          <Brain size={20} className="text-[#FF006E] mb-2 group-hover:scale-110 transition-transform" />
          <p className="text-sm font-semibold text-[#E6F1FF]">কুইজ</p>
          <p className="text-xs text-[#E6F1FF]/40">জ্ঞান পরীক্ষা</p>
        </button>
        <button
          onClick={() => setView("progress")}
          className="glass-card rounded-2xl p-4 text-left hover:border-[#FFD700]/30 transition-all duration-300 group"
        >
          <TrendingUp size={20} className="text-[#FFD700] mb-2 group-hover:scale-110 transition-transform" />
          <p className="text-sm font-semibold text-[#E6F1FF]">প্রগ্রেস</p>
          <p className="text-xs text-[#E6F1FF]/40">{progressPercent}% সম্পূর্ণ</p>
        </button>
        <button
          onClick={() => {
            setWritingKanji(nextKanji);
            setView("write");
          }}
          className="glass-card rounded-2xl p-4 text-left hover:border-[#00F0FF]/30 transition-all duration-300 group"
        >
          <PenTool size={20} className="text-[#00F0FF] mb-2 group-hover:scale-110 transition-transform" />
          <p className="text-sm font-semibold text-[#E6F1FF]">লেখা</p>
          <p className="text-xs text-[#E6F1FF]/40">অনুশীলন করুন</p>
        </button>
      </motion.div>
    </motion.div>
  );

  // ─── Deck View ──────────────────────────────────────────────────
  const DeckView = () => (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="relative z-10 px-4 pt-6 pb-32"
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={() => setView("dashboard")}
          className="flex items-center gap-2 text-sm text-[#E6F1FF]/60 hover:text-[#00F0FF] transition-colors"
        >
          <ChevronLeft size={18} />
          ড্যাশবোর্ড
        </button>
        <h2 className="text-lg font-semibold text-[#E6F1FF]">কানজি সংগ্রহ</h2>
        <span className="text-xs text-[#00F0FF]/60">{filteredKanji.length}টি</span>
      </div>

      {/* Search */}
      <div className="relative mb-4">
        <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#E6F1FF]/30" />
        <input
          type="text"
          placeholder="কানজি, অর্থ, বা রিডিং দিয়ে খুঁজুন..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-11 pr-4 py-3 rounded-xl glass-card text-sm text-[#E6F1FF] placeholder:text-[#E6F1FF]/30 focus:outline-none focus:border-[#00F0FF]/40 transition-colors"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery("")}
            className="absolute right-4 top-1/2 -translate-y-1/2"
          >
            <X size={14} className="text-[#E6F1FF]/30 hover:text-[#E6F1FF]/60" />
          </button>
        )}
      </div>

      {/* Category Filter */}
      <div className="flex gap-2 overflow-x-auto pb-4 mb-2 scrollbar-hide">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`category-chip ${activeCategory === cat ? "active" : ""}`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Kanji Grid */}
      <div className="grid grid-cols-4 sm:grid-cols-5 gap-3">
        {filteredKanji.map((k, i) => {
          const isLearned = learnedKanji.has(k.id);
          return (
            <motion.button
              key={k.id}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.01 }}
              whileHover={{ scale: 1.08, y: -4 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setSelectedKanji(k)}
              className={`kanji-node aspect-square ${isLearned ? "mastered" : ""}`}
            >
              <span
                className={`font-jp-serif text-2xl sm:text-3xl ${
                  isLearned ? "text-[#FF006E]" : "text-[#E6F1FF]/80"
                }`}
              >
                {k.kanji}
              </span>
              {isLearned && (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-1 -right-1"
                >
                  <Star size={12} className="text-[#FF006E] fill-[#FF006E]" />
                </motion.div>
              )}
            </motion.button>
          );
        })}
      </div>

      {filteredKanji.length === 0 && (
        <div className="text-center py-20">
          <Search size={32} className="text-[#E6F1FF]/20 mx-auto mb-3" />
          <p className="text-sm text-[#E6F1FF]/40">কোনো কানজি পাওয়া যায়নি</p>
        </div>
      )}
    </motion.div>
  );

  // ─── Progress View ──────────────────────────────────────────────
  const ProgressView = () => {
    const categoryProgress = useMemo(() => {
      return categories
        .filter((c) => c !== "সব")
        .map((cat) => {
          const catKanji = kanjiData.filter((k) => k.category === cat);
          const learned = catKanji.filter((k) => learnedKanji.has(k.id)).length;
          return { category: cat, total: catKanji.length, learned, percent: Math.round((learned / catKanji.length) * 100) };
        });
    }, [learnedKanji]);

    const recentLearned = useMemo(() => {
      return kanjiData
        .filter((k) => learnedKanji.has(k.id))
        .slice(-12)
        .reverse();
    }, [learnedKanji]);

    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="relative z-10 px-4 pt-6 pb-32 max-w-lg mx-auto"
      >
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => setView("dashboard")}
            className="flex items-center gap-2 text-sm text-[#E6F1FF]/60 hover:text-[#00F0FF] transition-colors"
          >
            <ChevronLeft size={18} />
            ড্যাশবোর্ড
          </button>
          <h2 className="text-lg font-semibold text-[#E6F1FF]">অগ্রগতি</h2>
          <Award size={18} className="text-[#FFD700]" />
        </div>

        {/* Overall Stats */}
        <div className="glass-card rounded-2xl p-6 mb-6 text-center">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", damping: 12 }}
            className="relative w-32 h-32 mx-auto mb-4"
          >
            <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="42" fill="none" stroke="rgba(230,241,255,0.08)" strokeWidth="8" />
              <motion.circle
                cx="50"
                cy="50"
                r="42"
                fill="none"
                stroke="url(#gradient)"
                strokeWidth="8"
                strokeLinecap="round"
                strokeDasharray={`${2 * Math.PI * 42}`}
                initial={{ strokeDashoffset: 2 * Math.PI * 42 }}
                animate={{ strokeDashoffset: 2 * Math.PI * 42 * (1 - progressPercent / 100) }}
                transition={{ duration: 1.5, ease: "easeOut" }}
              />
              <defs>
                <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#00F0FF" />
                  <stop offset="100%" stopColor="#FF006E" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-2xl font-bold text-[#E6F1FF]">{progressPercent}%</span>
            </div>
          </motion.div>
          <p className="text-sm text-[#E6F1FF]/60">
            <span className="text-[#00F0FF] font-bold">{masteredCount}</span> / {totalCount} কানজি মাস্টার্ড
          </p>
        </div>

        {/* Category Breakdown */}
        <h3 className="text-sm font-semibold text-[#E6F1FF]/60 mb-3">বিভাগ অনুযায়ী</h3>
        <div className="space-y-3 mb-8">
          {categoryProgress.map((cat) => (
            <div key={cat.category} className="glass-card rounded-xl p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-[#E6F1FF]/80">{cat.category}</span>
                <span className="text-xs text-[#00F0FF]/60">
                  {cat.learned}/{cat.total}
                </span>
              </div>
              <div className="w-full h-2 rounded-full bg-[#E6F1FF]/10 overflow-hidden">
                <motion.div
                  className="h-full rounded-full"
                  style={{
                    background:
                      cat.percent === 100
                        ? "#FF006E"
                        : "linear-gradient(90deg, #00F0FF, #FF006E)",
                  }}
                  initial={{ width: 0 }}
                  animate={{ width: `${cat.percent}%` }}
                  transition={{ duration: 0.8 }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Recently Learned */}
        {recentLearned.length > 0 && (
          <>
            <h3 className="text-sm font-semibold text-[#E6F1FF]/60 mb-3">সম্প্রতি শেখা</h3>
            <div className="flex flex-wrap gap-2">
              {recentLearned.map((k) => (
                <motion.button
                  key={k.id}
                  whileHover={{ scale: 1.1 }}
                  onClick={() => setSelectedKanji(k)}
                  className="w-12 h-12 rounded-xl flex items-center justify-center border border-[#FF006E]/30"
                  style={{ background: "rgba(255, 0, 110, 0.1)" }}
                >
                  <span className="font-jp-serif text-xl text-[#FF006E]">{k.kanji}</span>
                </motion.button>
              ))}
            </div>
          </>
        )}
      </motion.div>
    );
  };

  return (
    <div className="min-h-screen relative overflow-hidden" style={{ background: "#050508" }}>
      <Starfield />

      {/* Main Content */}
      <main className="relative min-h-screen">
        <AnimatePresence mode="wait">
          {view === "dashboard" && <DashboardView key="dashboard" />}
          {view === "deck" && <DeckView key="deck" />}
          {view === "progress" && <ProgressView key="progress" />}
        </AnimatePresence>
      </main>

      {/* Modals */}
      <AnimatePresence>
        {selectedKanji && (
          <StudyCard
            kanji={selectedKanji}
            onClose={() => setSelectedKanji(null)}
            onWrite={() => {
              setSelectedKanji(null);
              setWritingKanji(selectedKanji);
              setView("write");
            }}
            isLearned={learnedKanji.has(selectedKanji.id)}
            onToggleLearned={() => toggleLearned(selectedKanji.id)}
          />
        )}
        {view === "write" && writingKanji && (
          <WritingCanvas
            kanji={writingKanji.kanji}
            onClose={() => {
              setView("dashboard");
              setWritingKanji(null);
            }}
            onComplete={() => toggleLearned(writingKanji.id)}
          />
        )}
        {view === "quiz" && (
          <QuizMode onClose={() => setView("dashboard")} />
        )}
      </AnimatePresence>

      {/* Bottom Navigation */}
      {view !== "write" && view !== "quiz" && (
        <nav className="fixed bottom-0 left-0 right-0 z-40 px-4 pb-4 pt-2">
          <div
            className="max-w-sm mx-auto flex items-center justify-around rounded-2xl py-2 px-2"
            style={{
              background: "rgba(10, 10, 15, 0.85)",
              backdropFilter: "blur(20px)",
              border: "1px solid rgba(0, 240, 255, 0.1)",
            }}
          >
            <button
              onClick={() => setView("dashboard")}
              className={`nav-item ${view === "dashboard" ? "active" : ""}`}
            >
              <Sparkles size={20} />
              <span className="text-[10px]">হোম</span>
            </button>
            <button
              onClick={() => setView("deck")}
              className={`nav-item ${view === "deck" ? "active" : ""}`}
            >
              <BookOpen size={20} />
              <span className="text-[10px]">ডেক</span>
            </button>
            <button
              onClick={() => setView("quiz")}
              className="nav-item"
            >
              <Brain size={20} />
              <span className="text-[10px]">কুইজ</span>
            </button>
            <button
              onClick={() => setView("progress")}
              className={`nav-item ${view === "progress" ? "active" : ""}`}
            >
              <Trophy size={20} />
              <span className="text-[10px]">প্রগ্রেস</span>
            </button>
          </div>
        </nav>
      )}
    </div>
  );
}
